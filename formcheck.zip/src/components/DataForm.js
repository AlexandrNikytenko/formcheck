import { useState } from "react";
import InputForm from "./inputForm";

const initialFormData = {
  default_value: "",
  value: "",
  validation: "",
  min_value: "",
  max_value: "",
  options: "",
  type: "",
};

function DataForm({data}) {
  const [formData, setFormData] = useState(initialFormData);
  const [result, setResult] = useState(null);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setResult(formData);
    setFormData(initialFormData)
    console.log(formData);
  };

  return (
    <>
      <form onSubmit={handleSubmit}>
        <label>
          Deafault_value:
          <InputForm
            type={data.default_value}
            name="default_value"
            value={formData.default_value}
            handleChange={handleChange}
          />
        </label>
        <br />

        <label>
          Value:
          <InputForm
            type={data.value}
            name="value"
            value={formData.value}
            handleChange={handleChange}
          />
        </label>
        <br />

        <label>
          Validation:
          <input
            type="text"
            name="validation"
            value={formData.validation}
            onChange={handleChange}
          />
        </label>
        <br />

        <label>
          Min Value:
          <InputForm
            type={data.min_value}
            name="min_value"
            value={formData.min_value}
            handleChange={handleChange}
          />
        </label>
        <br />

        <label>
          Max Value:
          <InputForm
            type={data.max_value}
            name="max_value"
            value={formData.max_value}
            handleChange={handleChange}
          />
        </label>
        <br />

        <label>
          Options:
          <input
            type="text"
            name="options"
            value={formData.options}
            onChange={handleChange}
          />
        </label>
        <br />

        <label>
          Type:
          <InputForm
            type={data.type}
            name="type"
            value={formData.type}
            handleChange={handleChange}
          />
        </label>
        <br />
        <button type="submit">Submit</button>
      </form>

      <br />
      {result && (
        <>
          {result.default_value && <p>default_value:{result.default_value}</p>}
          {result.value && <p>value:{result.value}</p>}
          {result.validation && <p>validation:{result.validation}</p>}
          {result.min_value && <p>min_value:{result.min_value}</p>}
          {result.max_value && <p>max_value:{result.max_value}</p>}
          {result.options && <p>options:{result.options}</p>}
          {result.type && <p>type:{result.type}</p>}
        </>
      )}
    </>
  );
}

export default DataForm;
