import React from "react";

function InputForm({ type, name, value, handleChange }) {
  switch (type) {
    case "string":
      return (
        <input type="text" name={name} value={value} onChange={handleChange} />
      );
    case "longtext":
      return (
        <textarea
          name={name}
          rows={5}
          cols={33}
          value={value}
          onChange={handleChange}
        ></textarea>
      );
    case "dropdown":
      return (
        <select name={name} value={value} onChange={handleChange}>
          <option value="option 1">option 1</option>
          <option value="option 2">option 2</option>
          <option value="option 3">option 3</option>
          <option value="option 4">option 4</option>
        </select>
      );
    case "number":
      return (
        <input
          type="number"
          name={name}
          value={value}
          onChange={handleChange}
        />
      );
    case "boolean":
      return (
        <select name={name} value={value} onChange={handleChange}>
          <option>Choose boolean</option>
          <option value={true}>True</option>
          <option value={false}>False</option>
        </select>
      );
    default:
      return null;
  }
}

export default InputForm;
