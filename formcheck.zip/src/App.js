import './App.css';
import DataForm from './components/DataForm';


const data = {
  default_value: "boolean",
  value: "number",
  validation: "string",
  min_value: "number",
  max_value: "number",
  options: "",
  type: "longtext",
};

function App() {
  return (
    <div className="App">
      <DataForm data={data}/>
    </div>
  );
}

export default App;
